import random
import math

# Parameters
num_customers = 20
average_arrival_time = 5 
service_time = 3 

# Helper function to generate exponential inter-arrival times
def exponential(mean):
    return -mean * math.log(1 - random.random())

# Initialize lists
arrival_times = []
start_service = []
end_service = []
waiting_times = []
idle_times = []

# Simulation
current_time = 0
for i in range(num_customers):
    # Generate arrival time
    inter_arrival = exponential(average_arrival_time)
    arrival = arrival_times[-1] + inter_arrival if i > 0 else 0
    arrival_times.append(arrival)

    # Determine when service can start
    if i == 0:
        start = arrival
    else:
        start = max(arrival, end_service[i-1])
    
    end = start + service_time
    wait = start - arrival
    idle = max(0, start - end_service[i-1]) if i > 0 else start  # idle time is time server waits

    start_service.append(start)
    end_service.append(end)
    waiting_times.append(wait)
    idle_times.append(idle)

# Results
avg_waiting_time = sum(waiting_times) / num_customers
max_waiting_time = max(waiting_times)
total_idle_time = sum(idle_times)

# Print the results
print(f"{'Customer':<10}{'Arrival':<10}{'Start':<10}{'End':<10}{'Wait':<10}")
for i in range(num_customers):
    print(f"{i+1:<10}{arrival_times[i]:<10.2f}{start_service[i]:<10.2f}{end_service[i]:<10.2f}{waiting_times[i]:<10.2f}")

print("\nStatistics:")
print(f"Average Waiting Time: {avg_waiting_time:.2f} minutes")
print(f"Maximum Waiting Time: {max_waiting_time:.2f} minutes")
print(f"Total Server Idle Time: {total_idle_time:.2f} minutes")
